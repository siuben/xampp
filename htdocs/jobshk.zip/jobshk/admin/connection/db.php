<?php
$conn=mysqli_connect("localhost", "root","y26370131","job_portal");
?>