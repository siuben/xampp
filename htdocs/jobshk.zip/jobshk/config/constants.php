<?php

define('EMAIL', 'siuben123@gmail.com');
define('PASSWORD', 'y26350632');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'y26370131');
define('DB_NAME', 'job_portal');