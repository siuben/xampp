<?php require_once 'controllers/employer_authController.php'; ?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="style.css">
	<title>Password message</title>
</head>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-4 offset-md-4 form-div login">
		 <p>
		 	An email with the password reset link has been sent to your personal email address.
         </p>
		</div>
	</div>
</div>
</body>
</html>